package com.airline.reservation.io;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IoApplicationTests {

	@Test
	void contextLoads() {
	}

}
