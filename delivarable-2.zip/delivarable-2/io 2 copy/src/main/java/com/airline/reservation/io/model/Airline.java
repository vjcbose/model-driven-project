package com.airline.reservation.io.model;

import lombok.Value;

@Value


public class Airline {
	private String name;
	

}
